#ifndef VARBUILDER_H_INCLUDED
#define VARBUILDER_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <inttypes.h>
#include <stdint.h>

void buildVarName(char varName[], char line[]);

void buildValueAndSize(char num[], char size[], char val[]);


#endif