#include "VarBuilder.h"

void buildVarName(char varName[], char line[])
{
	int i = 0;
	//build the variable name string
	while (line[i] != ':')
	{
		if (!isspace(line[i]))
		{
			varName[i] = line[i];					
		}
		i++;
	}
}

void buildValueAndSize(char num[], char size[], char val[])
{
	int j = 0;
	int s = 0;
	while (val[j] != ':') //build value
	{
		num[j] = val[j];
		j++;
	}
	j++;
	while (val[j] != '\0') //build size
	{
		size[s] = val[j];
		j++;
		s++;
	}
}

void buildValue(char num[], char val[])
{
	int i = 0;
	while (val[i] != '\0')
	{
		num[i] = val[i];
		i++;
	}
}

void buildCharArray(char line[], char arr[])
{
	int i = 0;
	while (line[i] != '.')
	{
		i++;
	}
	while (line[i] != ' ')
	{
		i++;
	}
	while (line[i] == ' ')
	{
		i++;
	}
	int s = 0;
	while (line[i] != '\0')
	{
		arr[s] = line[i];
	}
}
void buildIntArray(char arr[], int realArr[])
{
	int i = 0;
	int s = 0;
	char num[4];
	while (arr[i] != '\0')
	{
		
	}
}


