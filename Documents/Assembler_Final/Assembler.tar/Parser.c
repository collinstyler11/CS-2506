#include "Parser.h"
#include "Register.h"
#include "Printer.h"
#include "VarBuilder.h"


FILE *inputFile;
FILE *outputFile;
FILE *table;
FILE *dataFile;

bool arrayFormat(char arr[]);
void labelPrint(char label[]);

int numVars = 0;
int numArrs = 0;
int numSyms = 0;
int numText = 0;

Arr arrTable[10];
Var dataTable[10];
Symbol symTable[10];
Text textTable[10];

int main(int argc, char **argv)
{	
	char symbols[9] = "-symbols";
	int symbolComp = strcmp(argv[1], symbols);
	char inputFileName[30];
	char outputFileName[30];
	char tableFileName[30];
	char dataFileName[30];
	if (symbolComp == 0)
	{
		strcpy(inputFileName, argv[2]); 
		strcpy(tableFileName, argv[2]);//will have to increase for -s
		strcpy(dataFileName, argv[2]);
		strcpy(outputFileName, argv[3]);
		inputFile = fopen(inputFileName, "r");
	}
	else
	{

		strcpy(inputFileName, argv[1]); 
		strcpy(tableFileName, argv[1]);//will have to increase for -s
		strcpy(dataFileName, argv[1]);
		strcpy(outputFileName, argv[2]);
		inputFile = fopen(inputFileName, "r");
		}
	if (inputFile == NULL)
	{
		fprintf(stderr, "Input file cannot be opened\n");
		exit(1);
	}
	
	outputFile = fopen(outputFileName, "w");

	if (outputFile == NULL)
	{
		fprintf(stderr, "Output file cannot be opened\n");
		exit(1);
	}

	table = fopen(tableFileName, "r");
	dataFile = fopen(dataFileName, "r");

	//---R-Format--------
	char add[4] = "add"; //000000 rs rt rd 00000 100000
	char nor[4] = "nor"; //000000 rs rt rd 00000 100111
	char and[4] = "and"; //000000 rs rt rd 00000 100100
	char mul[4] = "mul"; //011100 rs rt rd 00000 000010
	char or[3] = "or";   //000000 rs rt rd 00000 100101
	char sub[4] = "sub"; //000000 rs rt rd 00000 100010
	char sll[4] = "sll"; //000000 00000 rt rd sa 000000
	char sra[4] = "sra"; //000000 00000 rt rd sa 000011
	char slt[4] = "slt"; //000000 rs rt rd 00000 101010
	//-------------------

	//------I-Format------
	char addi[5] = "addi";   //001000 rs rt imm
	char andi[5] = "andi";   //001100 rs rt imm
	char slti[5] = "slti";   //001010 rs rt imm
	char ori[4] = "ori";     //001101 rs rt imm
	char addiu[6] = "addiu"; //001001 rs rt imm
	
	//--------------------

	//------J-Format------
	char bne[4] = "bne";     //000101 rs rt offset
	char beq[4] = "beq";     //000100 rs rt offset
	char blez[5] = "blez";   //000110 rs 00000 offset
	char bltz[5] = "bltz";   //000001 rs 00000 offset
	char ble[4] = "ble";     //
	char jay[2] = "j";       //000010 index
	//--------------------

	//------Special-------
	char lw[3] = "lw";       //100011 base rt offset
	char la[3] = "la"; 
	char sw[3] = "sw";
	char li[3] = "li";			 //001001 rt zero imm
	char lui[4] = "lui";
  	char sysc[8] = "syscall";
	char nop[4] = "nop";
	//--------------------

	char data[6] = ".data";
	char text[6] = ".text";
	char exit[5] = "exit:";
	char main[5] = "main:";
	char loop[5] = "loop:";
  	char doo[3] = "do:";

	char line[256];
	char instruction[20];
	char reg1[7];
	char reg2[7];
	char reg3[7];
	char imm[18];
	char imm_test[17];
	

	//-R-Format--
	int addComp;
	int subComp;
	int andComp;
	int mulComp;
	int orComp;
	int norComp;
	int sllComp;
	int sltComp;
	int sraComp;
	//-----------

	//-I-Format--
	int addiComp;
	int sltiComp;
	int addiuComp;
	int andiComp;
	int oriComp;
	//-----------
	
	//-J-Format--
	int bneComp;
	int beqComp;
	int blezComp;
	int bltzComp;
	int jComp;
	//-----------

	//-Special---
	int lwComp;
	int laComp;
	int luiComp;
	int liComp;
	int swComp;
	int sysComp;
	int nopComp;
	//-----------

	//-----------
	int exitComp;
	int mainComp;
	int loopComp;
	int dataComp;
	int textComp;
	//-----------
	
	char blank[256] = "0";
	bool passData1 = true;
	
	int dataAddress = 8192;
	int textAddress = -1;
	while (!feof(table))
	{
		fgets(line, 256, table);
		sscanf(line, "%s", instruction);
		
		//------R-Format------------------------
		addComp = strcmp( instruction, add);
	  	norComp = strcmp( instruction, nor);
		orComp = strcmp( instruction, or);
		mulComp = strcmp( instruction, mul);
		andComp = strcmp( instruction, and);
		subComp = strcmp( instruction, sub);
		sllComp = strcmp( instruction, sll);
		sltComp = strcmp( instruction, slt);
		sraComp = strcmp( instruction, sra);
		//--------------------------------------

		
		//------I-Format--------------------------
		addiComp = strcmp( instruction, addi);
		andiComp = strcmp( instruction, andi);
		addiuComp = strcmp( instruction, addiu);
		sltiComp = strcmp( instruction, slti);
		oriComp = strcmp( instruction, ori);
		//----------------------------------------

		//------J-Format--------------------------
		bneComp = strcmp( instruction, bne);
		beqComp = strcmp( instruction, beq);
		blezComp = strcmp( instruction, blez);
		bltzComp = strcmp( instruction, bltz);
		jComp = strcmp( instruction, jay);
		//----------------------------------------

		//------Special---------------------------
		lwComp = strcmp( instruction, lw);
		laComp = strcmp( instruction, la);
		swComp = strcmp( instruction, sw);
		luiComp = strcmp( instruction, lui);
		liComp = strcmp( instruction, li);
		sysComp = strcmp( instruction, sysc);
		nopComp = strcmp( instruction, nop);
		//----------------------------------------

		//------Symbols---------------------------
		exitComp = strcmp( instruction, exit);
		mainComp = strcmp( instruction, main);
		loopComp = strcmp( instruction, loop);
		dataComp = strcmp( instruction, data);
		textComp = strcmp( instruction, text);
		//----------------------------------------

		bool comm = (addComp == 0 || norComp == 0 || addiComp == 0 || bneComp == 0 || beqComp == 0 || lwComp == 0 || laComp == 0 || sysComp == 0 || dataComp == 0 || textComp == 0 || orComp == 0 || jComp == 0 || subComp == 0 || andComp == 0 || mulComp == 0 || sllComp == 0 || sltComp == 0 || sraComp == 0 || blezComp == 0 || bltz == 0 || luiComp == 0 || swComp == 0 || sltiComp == 0 || addiu == 0 || andiComp == 0 || oriComp == 0 || liComp == 0 || luiComp == 0 || nopComp == 0);
		int z = 0;
		while (isspace(line[z]))
		{
			z++;
		}
		if (line[z] == '\000')
		{
			continue;
		}
		if (dataComp == 0)
		{
			passData1 = true;
			continue;
		}
		if (line[0] == '\n')
		{
			continue;
		}
		else if (line[0] == '#')
		{
			continue;
		}
		else if (textComp == 0)
		{
			passData1 = false;
			continue;
		}
		else if (comm) // line is command
		{
			textAddress++;
			continue;
		}
		else //line is symbol
		{			
			int x = 0;
			while (isspace(line[x]))
			{
				x++;
			}
			if (line[x] == '#')
			{
				continue;
			}
			Symbol sym;
			char varName[20];
			char overwrite[20] = "\0";
			memcpy(varName, overwrite, 20);
			int i = 0;

			//build the variable name string
			while (instruction[i] != ':')
			{
				if (!isspace(instruction[i]))
				{
					varName[i] = instruction[i];					
				}
				i++;
			}
			
			if (passData1)
			{
				sym.address = dataAddress;
				dataAddress = dataAddress + 4;
			}
			else
			{
				textAddress++;
				sym.address = textAddress;				
			}
			strncpy(sym.name, varName, 20);
			//sym.address = textAddress;
			//sym.name = varName;
			symTable[numSyms] = sym;
			numSyms++;
		}
	strncpy(line, blank, 256);
 }
	textAddress = 0;
	dataAddress = 8188;
	bool sysCalled = false;
	bool passData = false;
	while(!feof(dataFile))
	{
		char dataLine[256];
		fgets(line, 256, dataFile);
		sscanf( line, "%s", instruction);
		dataComp = strcmp( instruction, data);
		if (dataComp != 0 && !passData)
		{
			continue;
		}
		else if (!passData && dataComp == 0)
		{
			passData = true;
			continue;
		}
		if (passData)
		{	
			int count = 0;
			
			char fillerName[20];
			char word[20];
			char val[20];
			char overwrite[20] = "\0";

			while (line[0] != '\n' && line[0] != '\000' && !feof(dataFile))
			{
				//dataAddress = dataAddress + 4;
				char fillerName[20];
				char word[6];
				char realWord[6] = ".word";
				char asc[8] = ".asciiz";
				char val[10];

				sscanf( line, "%s %s %s", fillerName, word, val);
				int wordComp = strcmp(word, realWord);
				int ascComp = strcmp(word, asc);
				char varName[20];
				if (wordComp == 0)
				{
					int valInt = atoi(val);
					memcpy(varName, overwrite, 20);
					
					
					bool isArray = arrayFormat(val);
					bool multiNum = isDiffArray(val);
					char num[10];
					char size[10];

					buildVarName(varName, line);
					

					if (isArray)
					{
						//Arr arr;
						buildValueAndSize(num, size, val);
						int valNum = atoi(num);
						int valSize = atoi(size);
						int array[valSize];
						for (int y = 0; y < valSize; y++)
						{
							array[y] = valNum; //place val in arr
							
						}
						Arr arr;
						strncpy(arr.name, varName, 20);
						dataAddress = dataAddress + (4 * valSize);
						arr.address = dataAddress;
						arr.value = valNum; 
						arr.size = valSize; 
						arrTable[numArrs] = arr;				
						numArrs++;
					}
					else if (multiNum)
					{
						//test
					}
					else
					{
						int valNum = atoi(val);
						Var var;
						strncpy(var.name, varName, 20);
						
						var.data = valNum;				
						//dataAddress = dataAddress + (4 * numVars);
						dataAddress = dataAddress + 4;				
						var.address = dataAddress;
						dataTable[numVars] = var;
						numVars++;
					}
				}
				else if (ascComp == 0)
				{

				}
				strncpy(line, blank, 256);
				fgets(line, 256, dataFile);
				count = count + 1;
			}
		}		
	}
	if (symbolComp != 0)
	{
		bool sysBeenCalled = false;
	while (!feof(inputFile) && !sysBeenCalled)
	{
		fgets(line, 256, inputFile);
		sscanf( line, "%s", instruction);
		//printf("Instruction is: %s\n", instruction);
		int length = strlen(line);

		dataComp = strcmp( instruction, data);
		textComp = strcmp( instruction, text);
		if (isspace(line[0]))
		{
			int iter = 0;
			bool newLine = false;
			while (isspace(line[iter]))
			{
				iter++;
				if (line[iter] == '\n')
				{
					newLine = true;
					break;
				}
			}
			if (newLine)
			{
				continue;
			}
		}
		
		if (line[0] == '\n')
		{
			//free(line);
			continue;
		}
		else if (line[0] == '#')
		{
			continue;
		}
		else if (dataComp == 0)
		{
			continue;
		}
		else if (textComp == 0)
		{
			continue;
		}
		else
		{
		//------R-Format------------------------
		addComp = strcmp( instruction, add);
	  	norComp = strcmp( instruction, nor);
		orComp = strcmp( instruction, or);
		mulComp = strcmp( instruction, mul);
		andComp = strcmp( instruction, and);
		subComp = strcmp( instruction, sub);
		sllComp = strcmp( instruction, sll);
		sltComp = strcmp( instruction, slt);
		sraComp = strcmp( instruction, sra);
		//--------------------------------------

		
		//------I-Format--------------------------
		addiComp = strcmp( instruction, addi);
		andiComp = strcmp( instruction, andi);
		addiuComp = strcmp( instruction, addiu);
		oriComp = strcmp( instruction, ori);
		sltiComp = strcmp( instruction, slti);
		//----------------------------------------

		//------J-Format--------------------------
		bneComp = strcmp( instruction, bne);
		beqComp = strcmp( instruction, beq);
		blezComp = strcmp( instruction, blez);
		bltzComp = strcmp( instruction, bltz);
		jComp = strcmp( instruction, jay);
		//----------------------------------------

		//------Special---------------------------
		lwComp = strcmp( instruction, lw);
		laComp = strcmp( instruction, la);
		swComp = strcmp( instruction, sw);
		luiComp = strcmp( instruction, lui);
		liComp = strcmp( instruction, li);
		sysComp = strcmp( instruction, sysc);
		nopComp = strcmp( instruction, nop);
		//----------------------------------------

		//------Symbols---------------------------
		exitComp = strcmp( instruction, exit);
		mainComp = strcmp( instruction, main);
		loopComp = strcmp( instruction, loop);
		dataComp = strcmp( instruction, data);
		textComp = strcmp( instruction, text);
		//----------------------------------------

		if (mainComp == 0)
		{
			continue;
		}
		else if (loopComp == 0)
		{
			continue;
		}
		else if (nopComp == 0)
		{
			fprintf(outputFile, "00000000000000000000000000000000\n");
			textAddress++;
		}
		else if (sraComp == 0 || sllComp == 0)
		{
			char number[3];
			sscanf(line, "%s %s %s %s", instruction, reg1, reg2, number);
			reg1[3] = ' ';
			reg2[3] = ' ';
			fprintf(outputFile, "00000000000");
			regPrint(reg2, outputFile);
			regPrint(reg1, outputFile);
			int immNum = atoi(number);
			print5Bit(immNum, outputFile);
			if (sraComp == 0)
			{
				fprintf(outputFile, "000011");
			}
			else
			{
				fprintf(outputFile, "000000");
			}
			textAddress++;
			fprintf(outputFile, "\n");
		}
		else if (addComp == 0 || norComp == 0 || orComp == 0 || subComp == 0 || andComp == 0 || mulComp == 0 || sltComp == 0)
		{
			sscanf(line, "%s %s %s %s", instruction, reg1, reg2, reg3);
			reg1[3] = ' ';
			reg2[3] = ' ';
			printBasicRType(addComp, norComp, orComp, subComp, andComp, mulComp, sltComp, outputFile, reg1, reg2, reg3);			
								
			fprintf(outputFile, "\n");
			textAddress++;
		}
		else if (addiComp == 0 || sltiComp == 0 || addiuComp == 0 || andiComp == 0 || oriComp == 0)
		{
			sscanf(line, "%s %s %s %s", instruction, reg1, reg2, imm);
			printImmediate(addiComp, sltiComp, addiuComp, andiComp, oriComp, reg1, reg2, outputFile);
			uint16_t wub = atoi(imm);
			printShort(wub, outputFile);
     		//immPrint(imm, outputFile);
			fprintf(outputFile, "\n");
			textAddress++;
		    //fprintf(outputFile, "\n");
		}
		else if (blezComp == 0 || bltzComp == 0)
		{
			char offset[20];
			sscanf(line, "%s %s %s", instruction, reg1, offset);
			if (bltzComp == 0)
			{
				fprintf(outputFile, "000001");
			}
			else //blez
			{
				fprintf(outputFile, "000110");
			}	
			regPrint(reg1, outputFile);
			fprintf(outputFile, "00000");
			uint16_t wub = atoi(imm);
			printShort(wub, outputFile);
			//immPrint(offset, outputFile);
			fprintf(outputFile, "\n");	
			textAddress++;
		}
		else if (jComp == 0)
		{
			 char offset[20];	
			 sscanf(line, "%s %s", instruction, offset);
			 fprintf(outputFile, "0000100000000000");
			 labelPrint(offset);
			 textAddress++;
				fprintf(outputFile, "\n");
		}
		else if (bneComp == 0 || beqComp == 0)
		{
			 char offset[20];
	
			 sscanf(line, "%s %s %s %s", instruction, reg1, reg2, offset);
			if (bneComp == 0)
			{
				fprintf(outputFile, "000101");
				regPrint(reg1, outputFile);
				regPrint(reg2, outputFile);
				labelPrint(offset);
			}
			else  //beq
			{
				fprintf(outputFile, "000100");
				regPrint(reg1, outputFile);
				regPrint(reg2, outputFile);
				labelPrint(offset);
			}
		fprintf(outputFile, "\n");
		textAddress++;
		//symbolPrint(offset, textAddress);
		}
		else if (laComp == 0 || lwComp == 0 || luiComp == 0 || liComp == 0 || swComp == 0)
		{
			if (liComp == 0)
			{
				char var[20];
				sscanf(line, "%s %s %s", instruction, reg1, var);
				fprintf(outputFile, "00100100000");
				regPrint(reg1, outputFile);
				uint16_t wub = atoi(var);
				printShort(wub, outputFile);
				//immPrint(var, outputFile);
			}
			else if (lwComp == 0)
			{
				char var[20];
				char rewriteVar[20] = "0";
				char rewriteBase[5] = "0";
	
				char base[5];
				strncpy(var, rewriteVar, 20);
				strncpy(base, rewriteBase, 5);
				sscanf(line, "%s %s %s", instruction, reg1, var);
				fprintf(outputFile, "100011");
				
				char offset[7]; // 7 because largest 16 bit is 6 places
				strncpy(offset, rewriteBase, 5);
				int iter = 0;
				while (var[iter] != '(')
				{
					offset[iter] = var[iter];
					iter++;
				}
				iter++;
				int y = 0;
				while (var[iter] != ')')
				{
					base[y] = var[iter];
					iter++;
					y++;
				}
				
				regPrint(base, outputFile);
				regPrint(reg1, outputFile);
				uint16_t wub = atoi(offset);
				//printShort(wub);
				immPrint(offset, outputFile);
			}
			else if (swComp == 0)
			{
				char var[20];
				char base[5];
				sscanf(line, "%s %s %s", instruction, reg1, var);
				fprintf(outputFile, "101011");
				
				char offset[7]; // 7 because largest 16 bit is 6 places
				int iter = 1;
				int s = 0;
				while (var[iter] != '(')
				{
					offset[iter] = var[iter];
					iter++;
				}
				iter++;
				while (var[iter] != ')')
				{
					base[s] = var[iter];
					iter++;
					s++;
				}
				
				regPrint(base, outputFile);
				regPrint(reg1, outputFile);
				uint16_t wub = atoi(offset);
				//printShort(wub);
				immPrint(offset, outputFile);
			}
			else if (luiComp == 0)
			{
				char var[20];
				sscanf(line, "%s %s %s", instruction, reg1, var);
				fprintf(outputFile, "00111100000");
				regPrint(reg1, outputFile);
				uint16_t wub = atoi(var);
				printShort(wub);
				//immPrint(var, outputFile);
			}
			else // la
			{
				char var[20];
				sscanf(line, "%s %s %s", instruction, reg1, var);
				fprintf(outputFile, "001000");		 	
				fprintf(outputFile, "00000");
				regPrint(reg1, outputFile);
				labelPrint(var);
				
			}
		fprintf(outputFile, "\n");
		textAddress++;
		}
		else if (sysComp == 0)
		{
			fprintf(outputFile, "00000000000000000000000000001100");
			fprintf(outputFile, "\n");
			textAddress++;
			sysBeenCalled = true;
			continue;
		}
		else
		{
			continue;
		}				
				
	}
	}
	fprintf(outputFile, "\n");
	int z = 0;
	while (textTable[z].address > 0)
	{
		printWord(textTable[z].text, outputFile);
		fprintf(outputFile, "00000000000000000000000000000000\n");
		z++;
	}
	//int i = 0;
	if (arrTable[0].size > 0)
	{
		for (int j = 0; j < arrTable[0].size; j++)
		{
			if (arrTable[0].value >= 0)
			{
				fprintf(outputFile, "0000000000000000");
			}
      		else
      		{
      			fprintf(outputFile, "1111111111111111");
      		}
			uint16_t immNum = arrTable[0].value;
			printShort(immNum, outputFile);
        	fprintf(outputFile, "\n");
		}
	}
	//fprintf(outputFile, "\n");
	for (int j = 0; j < numVars; j++)
	{
		if (dataTable[j].address > 0)
		{
			if (dataTable[j].data >= 0)
			{
      			fprintf(outputFile, "0000000000000000");
      		}
      		else
      		{
      			fprintf(outputFile, "1111111111111111");
      		}
			uint16_t val = dataTable[j].data;
			printShort(val, outputFile);		
      		fprintf(outputFile, "\n");
		}
	}
}
else
{
	fprintf(outputFile, "Address		   Symbol\n");
	fprintf(outputFile, "------------------------------\n");
	for (int i = 0; i < numSyms; i++)
	{
		fprintf(outputFile, "0x");
		fprintf(outputFile, "%08X        %s\n", symTable[i].address, symTable[i].name);
	}
}
	
}

bool arrayFormat(char arr[])
{
	int i = 0;
	while (arr[i] != '\0')
	{
		if (arr[i] == ':')
		{
			return true;
		}
		i++;
	}
	return false;
}

void symbolPrint(char arr[], int offset)
{
	int len = strlen(arr);
	for (int i = 0; i < numSyms; i++)
	{
		if (strcmp(symTable[i].name, arr) == 0)
		{
			uint16_t loc = symTable[i].address - offset;
			printShort(loc, outputFile);
		}
	}
}

bool findLabel(char label[], int label_length, char dataLabel[], int dataTableLen)
{
  if (label_length != dataTableLen)
  {
  	return false;
  }
  else
  {
  	for (int i = 0; i < dataTableLen; i++)
  	{
  		if (label[i] != dataLabel[i])
  		{
  			return false;
  		}
  	}
  	return true;
  }
  
}

void labelPrint(char label[])
{
  int len = strlen(label);
  int addr = -1;
  for (int i = 0; i < numVars; i++)
  {
    int tempLen = strlen(dataTable[i].name);
	bool equal = findLabel(label, len, dataTable[i].name, tempLen);
		if (equal)
		{
			addr = dataTable[i].address;
			break;
		}
  }

  //-----------------------------------------

  if (addr == -1)
  {
    for (int i = 0; i < numArrs; i++)
    {
      int tempLen = strlen(arrTable[i].name);
			char str[20];
			strncpy(str, arrTable[i].name, 20);
			if (str[0] == label[0] && (str[1] == label[1] || str[1] == '\0'))
			{
				addr = arrTable[i].address;
				break;
			}
    }
  }

  //----------------------------------------
  
  if (addr == -1)
  {
    for (int i = 0; i < numSyms; i++)
    {
      int tempLen = strlen(symTable[i].name);
		  char str[20];
		  strncpy(str, symTable[i].name, 20);
			if (str[0] == label[0] && (str[1] == label[1] || str[1] == '\0'))
			{
				addr = symTable[i].address;
				break;
			}
    }
  }
  
  //---------Print out-------------------
  if (addr >= 0)
  {
    int temp[18];
	  int i = 1;
	  uint16_t immNum = addr;
	  printShort(immNum, outputFile);
  }
}





// On my honor:
//
// - I have not discussed the C language code in myprogram with
// anyone other than my instructor or the teaching assistants
// assigned to this course.
//
// - I have not used C language code obtained fromanother student,
// or any other unauthorized source, either modified or unmodified.
//
// - If any C language code or documentation used in my program
// was obtained from another source, such as a text book or course
// notes, that has been clearly noted with a proper citation in
// the comments of my program.
//
// Tyler Collins
