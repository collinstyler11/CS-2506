#ifndef PARSER_H
#define PARSER_H
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>

bool arrayFormat(char arr[]);
void labelPrint(char label[]);

struct _Symbol {
	char name[20];
	int address;
				};
typedef struct _Symbol Symbol;

struct _Var {
	char name[20];
	int address;
	int data;
			};
typedef struct _Var Var;

struct _Arr {
	char name[20];
	int address;
	int value;
	int size;
			};
typedef struct _Arr Arr;

struct _Text {
	char name[20];
	int address;
	char text[20];
	int size;
			 };
typedef struct _Text Text;
#endif
