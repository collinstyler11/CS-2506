#include "Printer.h"
#include "Register.h"

void printWord(char text[], FILE *outputFile)
{
	int max = 0;
	char temp[32];
	int count = 0;
	for (int i = 0; text[i] != '\0'; i++)
	{
		int mask = 0x80; //1000000 moving the bit down
		
		while (mask > 0)
		{
			temp[count] = (text[i] & mask) > 0;
			count++;
			mask >>= 1;
		}		
		max++;
		if (max % 4 == 0)
		{
			count = 0;
			for (int j = 31; j >= 0; j--)
			{
				fprintf(outputFile, "%d", temp[j]);
			}
			fprintf(outputFile, "\n");
		}
	}
}


void immPrint(char imm[], FILE * outputFile)
{
	int temp[18];
	int i = 1;
	int immNum = atoi(imm);
	while (immNum != 0)
	{
		temp[i] = immNum % 2;
		if (temp[i] == -1)
		{
			temp[i] = 1;
		}
		i = i + 1;
			immNum = immNum / 2;
	}
	while (i < 17)
 	 {
		 temp[i] = 0;
			i++;
	}
	i = i - 1;
	if (atoi(imm) < 0 && atoi(imm) > -32768)
	{
		invert(temp);
	}
	while (i > 0)
	{	
		 fprintf(outputFile, "%d", temp[i--]);
	}
}

void invert(int neg[])
{
	for (int i = 0; i < 18; i++)
	{
		if (neg[i] == 0)
		{
			neg[i] = 1;
		}
		else if (neg[i] == 1)
		{
			neg[i] = 0;
		}
	}
	for (int i = 17; i > 0; i--)
	{
		if (neg[i] == 1)
		{
			neg[i] = 0;
		}
		else
		{
			neg[i] = 1;
			break;
		}
	}
}

void printShort(uint16_t Byte, FILE * outputFile)
{
	uint16_t Mask = 0x8000;
	for (int bit = 16; bit > 0; bit--)
	{
		fprintf(outputFile, "%c", ((Byte & Mask) == 0 ? '0' : '1'));
		Mask = Mask >> 1;
	}
}

void print5Bit(int Byte, FILE * outputFile)
{
	int a[5] = {0};
	int i = 0;
	while (Byte > 0)
	{
		a[i] = Byte % 2;
		i++;
		Byte = Byte / 2;
	}
	for (int j = i - 1; j >= 0; j--)
	{
		fprintf(outputFile, "%d", a[j]);
	}
}

void printInt(uint32_t Byte, FILE * outputFile)
{
	
}

bool isDiffArray(char arr[])
{
	int i = 0;
	while (arr[i] != '\0')
	{
		if (arr[i] == ',')
		{
			return true;
		}
		i++;
	}
	return false;
}

void printBasicRType(int addComp, int norComp, int orComp, int subComp, int andComp, int mulComp, int sltComp, FILE * outputFile, char reg1[], char reg2[], char reg3[])
{
	if (addComp == 0)
	{
		fprintf(outputFile, "000000");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000100000");
	}
	else if (sltComp == 0)
	{
		fprintf(outputFile, "000000");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000101010");
	}
	else if (norComp == 0)
	{
		fprintf(outputFile, "000000");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000100111");
	}				
	else if (subComp == 0)
	{
		fprintf(outputFile, "000000");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000100010");
	}
	else if (mulComp == 0)
	{
		fprintf(outputFile, "011100");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000000010");
	}
	else if (orComp == 0)
	{
		fprintf(outputFile, "000000");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000100101");
	}
	else //and
	{
		fprintf(outputFile, "000000");
		regPrint(reg2, outputFile);
		regPrint(reg3, outputFile);
		regPrint(reg1, outputFile);
		fprintf(outputFile, "00000100100");
	}					
}

void printImmediate(int addiComp, int sltiComp, int addiuComp, int andiComp, int oriComp, char reg1[], char reg2[], FILE * outputFile)
{
	if (addiComp == 0)
	{
		fprintf(outputFile, "001000");
	}
	else if (sltiComp == 0)
	{
		fprintf(outputFile, "001010");
	}
	else if (addiuComp == 0)
	{
		fprintf(outputFile, "001001");
	}
	else if (andiComp == 0)
	{
		fprintf(outputFile, "001100");
	}
	else  //ori
	{
		fprintf(outputFile, "001101");
	}
	regPrint(reg2, outputFile);
	regPrint(reg1, outputFile);
}

