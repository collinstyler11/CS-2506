#include "Register.h"

void regPrint(char reg[], FILE * outputFile)
{
	if (reg[1] == 's')
	{
		switch (reg[2])
		{
			case '0': fprintf(outputFile, "10000");
			break;
			case '1': fprintf(outputFile, "10001");
			break;
			case '2': fprintf(outputFile, "10010");
			break;
			case '3': fprintf(outputFile, "10011");
			break;
			case '4': fprintf(outputFile, "10100");
			break;
			case '5': fprintf(outputFile, "10101");
			break;
			case '6': fprintf(outputFile, "10110");
			break;
			case '7': fprintf(outputFile, "10111");
			break;
			case '8': fprintf(outputFile, "11000");
			break;
			case '9': fprintf(outputFile, "11001");
			break;
			default : 
			break;
		}
	}
	else if (reg[1] == 't')
	{
		switch (reg[2])
		{
			case '0': fprintf(outputFile, "01000");
			break;
			case '1': fprintf(outputFile, "01001");
			break;
			case '2': fprintf(outputFile, "01010");
			break;
			case '3': fprintf(outputFile, "01011");
			break;
			case '4': fprintf(outputFile, "01100");
			break;
			case '5': fprintf(outputFile, "01101");
			break;
			case '6': fprintf(outputFile, "01110");
			break;
			case '7': fprintf(outputFile, "01111");
			break;
			case '8': fprintf(outputFile, "01000");
			break;
			case '9': fprintf(outputFile, "01001");
			break;
			default : 
			break;
		}
	}
	else if (reg[1] == 'v')
	{
		switch (reg[2])
		{
			case '0': fprintf(outputFile, "00010");
			break;
			case '1': fprintf(outputFile, "00011");
			break;
			case '2': fprintf(outputFile, "00010");
			break;
			case '3': fprintf(outputFile, "00011");
			break;
			case '4': fprintf(outputFile, "00110");
			break;
			case '5': fprintf(outputFile, "00111");
			break;
			case '6': fprintf(outputFile, "00110");
			break;
			case '7': fprintf(outputFile, "00111");
			break;
			case '8': fprintf(outputFile, "01010");
			break;
			case '9': fprintf(outputFile, "01011");
			break;
			default : 
			break;
		}
	}
	else if (reg[1] == 'a')
	{
		switch (reg[2])
		{
			case '0': fprintf(outputFile, "00100");
			break;
			case '1': fprintf(outputFile, "00101");
			break;
			case '2': fprintf(outputFile, "00110");
			break;
			case '3': fprintf(outputFile, "00111");
			break;
			case '4': fprintf(outputFile, "01100");
			break;
			case '5': fprintf(outputFile, "01101");
			break;
			case '6': fprintf(outputFile, "01110");
			break;
			case '7': fprintf(outputFile, "01111");
			break;
			case '8': fprintf(outputFile, "10100");
			break;
			case '9': fprintf(outputFile, "10101");
			break;
			default : 
			break;
		}
	}
	else if (reg[1] = 'z')
	{
		fprintf(outputFile, "00000");
	}
	else 
	{
		fprintf(outputFile, "Error: %s", reg);
	}
} 


