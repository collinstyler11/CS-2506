#ifndef REGISTERPRINT_H_INCLUDED
#define REGISTERPRINT_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>

void regPrint(char reg[], FILE *outputFile);

#endif

