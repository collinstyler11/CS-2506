#ifndef PRINTER_H_INCLUDED
#define PRINTER_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <inttypes.h>
#include <stdint.h>

void immPrint(char imm[], FILE * outputFile);

void printWord(char text[], FILE * outputFile);

#endif

