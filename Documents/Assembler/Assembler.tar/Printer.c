#include "Printer.h"

void printWord(char text[], FILE *outputFile)
{
	int max = 0;
	char temp[32];
	int count = 0;
	for (int i = 0; text[i] != '\0'; i++)
	{
		int mask = 0x80; //1000000 moving the bit down
		
		while (mask > 0)
		{
			temp[count] = (text[i] & mask) > 0;
			count++;
			mask >>= 1;
		}		
		max++;
		if (max % 4 == 0)
		{
			count = 0;
			for (int j = 31; j >= 0; j--)
			{
				fprintf(outputFile, "%d", temp[j]);
			}
			fprintf(outputFile, "\n");
		}
	}
}


void immPrint(char imm[], FILE * outputFile)
{
	int temp[18];
	int i = 1;
	int immNum = atoi(imm);
	while (immNum != 0)
	{
		temp[i] = immNum % 2;
		if (temp[i] == -1)
		{
			temp[i] = 1;
		}
		i = i + 1;
			immNum = immNum / 2;
	}
	while (i < 17)
 	 {
		 temp[i] = 0;
			i++;
	}
	i = i - 1;
	if (atoi(imm) < 0 && atoi(imm) > -32768)
	{
		invert(temp);
	}
	while (i > 0)
	{	
		 fprintf(outputFile, "%d", temp[i--]);
	}
}

void invert(int neg[])
{
	for (int i = 0; i < 18; i++)
	{
		if (neg[i] == 0)
		{
			neg[i] = 1;
		}
		else if (neg[i] == 1)
		{
			neg[i] = 0;
		}
	}
	for (int i = 17; i > 0; i--)
	{
		if (neg[i] == 1)
		{
			neg[i] = 0;
		}
		else
		{
			neg[i] = 1;
			break;
		}
	}
}

void printShort(uint16_t Byte, FILE * outputFile)
{
	uint16_t Mask = 0x8000;
	for (int bit = 16; bit > 0; bit--)
	{
		fprintf(outputFile, "%c", ((Byte & Mask) == 0 ? '0' : '1'));
		Mask = Mask >> 1;
	}
}

void printInt(uint32_t Byte, FILE * outputFile)
{
	int Mask = 0x80000000;
	for (int bit = 32; bit > 0; bit--)
	{
		fprintf(outputFile, "%c", ((Byte & Mask) == 0 ? '0' : '1'));
		Mask = Mask >> 1;
	}
}

